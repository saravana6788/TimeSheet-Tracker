package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.vo.Person;


@Controller
public class TrackController {
	
	@RequestMapping("/")
	public String home(){
		//return "Hello World!!";
		System.out.println("Hello World!!!");
		return "index.html";
	}
	
	@RequestMapping("/person")
	public String personView(Model model){
		Person p=new Person();
		p.setName("Saravana Ganapathy");
		p.setEmpId(128053);
		model.addAttribute("person",p);
		return "personview";
	}
	
	@RequestMapping("/track")
	private String login(Model model){
		Person p=new Person();
		p.setName("Saravana Ganapathy");
		p.setEmpId(128053);
		model.addAttribute("person",p);
		System.out.println("Inside Login Controller...");
		
		return "tracker.html";
	}
}
