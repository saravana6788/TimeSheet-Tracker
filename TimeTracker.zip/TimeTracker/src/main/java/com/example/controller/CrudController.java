package com.example.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.vo.TimeSheet;

@RestController
@RequestMapping("/db")
public class CrudController {
	
	private Statement sta;
  public void dbConnection(){
	  Connection con=null;
	  //CrudController cc=new CrudController();
	 String url="jdbc:mysql://localhost:3306/track?user=root&password=sarav6788";

	 try{
		 con=DriverManager.getConnection(url);
		 sta=con.createStatement();
		 ResultSet rs=sta.executeQuery("select EMP_ID from track.timesheet_status where S_NO="+1);
		 while(rs.next()){
			 System.out.println(rs.getInt("EMP_ID"));
		 }
	 }catch(Exception e){
		 System.out.println("Exception Occured while connectiong to DB"+e);
	 }
  }
  @RequestMapping(value="{empId}")
  public List<TimeSheet> readPendingTimesheets(@PathVariable int empId){
	  
	  List<TimeSheet> timeSheetList=new ArrayList<TimeSheet>();
			  
	  ResultSet rs;
	  String status="N";
	  dbConnection();
	try {
		rs = sta.executeQuery("select * from track.timesheet_status where EMP_ID="+empId+" and SUBMISSION_STATUS="+"\'"+status+"\'");
		System.out.println("S_NO:EMP_ID:EMP_NAME:TIMESHEET:SUBMISSION_STATUS");
		while(rs.next()){
			TimeSheet ts=new TimeSheet();
			ts.setEmpId(rs.getInt(2));
			ts.setsNo(rs.getInt(1));
			ts.setEmpName(rs.getString(3));
			ts.setTimeSheet(rs.getString(4));
			ts.setStatus(rs.getString(5));
			timeSheetList.add(ts);
			 System.out.println(rs.getInt(1)+":"+rs.getInt(2)+":"+rs.getString(3)+":"+rs.getString(4)+":"+rs.getString(5));
			 
		 }
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return timeSheetList; 
	  
	
  }


@RequestMapping(method=RequestMethod.POST,value="/updateDb")
public int updateRecord(@RequestBody TimeSheet sheet){
	dbConnection();
	String status="Y";
	int s=0;
	try {
		s=sta.executeUpdate("UPDATE track.timesheet_status set SUBMISSION_STATUS="+"\'"+status+"\'"+" where S_NO="+sheet.getsNo());
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s;
}
}