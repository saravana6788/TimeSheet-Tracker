package com.example.vo;

public class UpdateDb {

	
	private String name;
	private int empId;
	private String dateRange;
	private String status;
}
