package com.example.vo;

public class TimeSheet {
	
	private int sNo;
	private int empId;
	private String empName;
	private String timeSheet;
	private String status;
	public int getsNo() {
		return sNo;
	}
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getTimeSheet() {
		return timeSheet;
	}
	public void setTimeSheet(String timeSheet) {
		this.timeSheet = timeSheet;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
