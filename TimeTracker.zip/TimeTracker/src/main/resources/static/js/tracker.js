angular.module("trackApp",['ngMaterial']).controller("TrackController",function($scope,$http,$window,$mdDialog){
	//$scope.time_no="2";
	var url="http://localhost:8080/db/128053";
	$http.get(url).success(function(response){
		$scope.time_no=response.length;
		//$window.alert($scope.time_no);
		$scope.timesheets=response;
		//$window.alert(time_no);
	});
	
	
	$scope.showModal=function(event){
		$mdDialog.show({
            clickOutsideToClose: true,
            scope: $scope,        
            preserveScope: true,           
            templateUrl: '../sheets.html',
            controller: function TrackController($scope, $mdDialog) {
               $scope.closeDialog = function() {
                  $mdDialog.hide();
               }
            }
         });
      };
      
      
      $scope.update=function(timesheets) {
    	  $mdDialog.hide();
    	  $scope.timesheets=timesheets;
    	  
    	  var updateUrl="http://localhost:8080/db/updateDb";
    	 // $window.alert($scope.timesheets.length);
    	  for(var i=0;i<$scope.timesheets.length;i++){
    		//  $window.alert($scope.timesheets[i]);
    	  $http.post(updateUrl,$scope.timesheets[i]).success(function(response){
    			$scope.message="Status updated Successfully";
    			
    		});
    	  }
      }     

	
	/*var updateUrl="http://localhost:8080/db/updateDb";
	$http.post(updateUrl,obj).success(function(response){
		$scope.message="Status updated Successfully";
	});*/
});

